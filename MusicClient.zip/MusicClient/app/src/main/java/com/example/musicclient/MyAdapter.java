package com.example.musicclient;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.KeyCommon.StoresSongData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private StoresSongData[] songs;
    private final SongClickListener listener;

    /*
    passing in the data and the listener defined in the main activity
     */
    public MyAdapter(StoresSongData[] songs, SongClickListener listener) {
        this.songs = songs;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.songitem, parent, false), listener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.song.setText(songs[position].title);
        holder.artist.setText(songs[position].name);
//        holder.thumbnail.setImageResource(songs[position].getThumbnail());
    }

    @Override
    public int getItemCount() {

        return songs.length;
    }

    /*
        This class creates a wrapper object around a view that contains the layout for
         an individual item in the list. It also implements the onClickListener so each ViewHolder in the list is clickable.
        It's onclick method will call the onClick method of the RVClickListener defined in
        the main activity.
     */
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnCreateContextMenuListener {

        public TextView song;
        public TextView artist;
        public ImageView thumbnail;
        ConstraintLayout layoutC;
        private SongClickListener listener;


        public ViewHolder(@NonNull View itemView, SongClickListener passedListener) {
            super(itemView);

            song = (TextView) itemView.findViewById(R.id.songName);
            artist = (TextView) itemView.findViewById(R.id.artistName);
            thumbnail = (ImageView) itemView.findViewById(R.id.thumbnail);
            layoutC = itemView.findViewById(R.id.recycler_view); //set context menu for each list item (long click)
            this.listener = passedListener;

            itemView.setOnClickListener(this); //set short click listener
        }

        @Override
        public void onClick(View v) {
            listener.onClick(v, getAdapterPosition());
            Log.i("ON_CLICK", "in the onclick in view holder");
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        }
    }
}
