package com.example.musicclient;

import android.app.AppComponentFactory;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.KeyCommon.SongsInfo;
import com.example.KeyCommon.StoresSongData;

import java.util.ArrayList;
import java.util.concurrent.RecursiveAction;

public class ListViewSongs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView songView = (RecyclerView) findViewById(R.id.recycler_view);

        songView.setLayoutManager(new LinearLayoutManager(this));
        songView.setHasFixedSize(true);

        //Define the listener with a lambda and access the name of the list item from the view
        SongClickListener listener = (view, position) -> {
            startForegroundService(MainActivity.songServiceIntent);
        };

        StoresSongData[] songs = MainActivity.allSongs;
        MyAdapter adapter = new MyAdapter(songs, listener);
        songView.setAdapter(adapter);
    }
}
