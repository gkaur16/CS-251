package com.example.musicclient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.KeyCommon.SongsInfo;
import com.example.KeyCommon.StoresSongData;

public class MainActivity extends AppCompatActivity {

    TextView statusService;
    Button listOfSong;
    SongsInfo mSongsInfo;

    public static StoresSongData[] allSongs;

    boolean checkBound = false;
    public static Intent songServiceIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusService = findViewById(R.id.textView);
        listOfSong = findViewById(R.id.btnList);

        if (getIntent().getBooleanExtra("Bound", false))
            checkBound = true;

        if(savedInstanceState != null){
            if(savedInstanceState.getBoolean("Bound"))
                checkBound = true;

            if (savedInstanceState.getCharSequence("Status") != null)
                statusService.setText(savedInstanceState.getCharSequence("Status"));
        }

        if (checkBound)
        {
            listOfSong.setVisibility(View.VISIBLE);
            bindService(songServiceIntent, SC, Context.BIND_AUTO_CREATE);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("Bound", checkBound);
        outState.putCharSequence("Status", statusService.getText());
    }

    public ServiceConnection SC = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mSongsInfo = SongsInfo.Stub.asInterface(service);

            try{
                allSongs = mSongsInfo.retrieveAllSongs();
                System.out.println(allSongs.length);
            } catch (RemoteException e) { e.printStackTrace(); }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    public void bindService(View view) {
        if(checkBound)
            statusService.setText("It was already Connected to Service!");

        else{
            songServiceIntent = new Intent(SongsInfo.class.getName());
            ResolveInfo info = getPackageManager().resolveService(songServiceIntent, 0);
            songServiceIntent.setComponent(new ComponentName(info.serviceInfo.packageName, info.serviceInfo.name));

            listOfSong.setVisibility(View.VISIBLE);
            bindService(songServiceIntent, this.SC, Context.BIND_AUTO_CREATE);
            statusService.setText("Hooray! Connected to Service");
            checkBound = true;
        }
    }

    public void unbindsService(View view) {
        if(!checkBound)
            statusService.setText("OOPS! Not Connected to Service");

        else{
            unbindService(this.SC);
            stopService(songServiceIntent);
            statusService.setText("OPPS! Disconnected from Service");
            checkBound = false;
            listOfSong.setVisibility(View.INVISIBLE);
        }
    }

//    public void listViewActivity(View view){
//        Intent intent = new Intent(this, ListViewSongs.class);
//        startActivity(intent);
//    }

}