package com.example.musicclient;

import android.view.View;

public interface SongClickListener {
    public void onClick(View view, int position);
}
