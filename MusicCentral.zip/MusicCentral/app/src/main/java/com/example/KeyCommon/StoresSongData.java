package com.example.KeyCommon;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

public class StoresSongData implements Parcelable {
    public String title;
    public String name;
    public Bitmap thumbnail;
    public String audio;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Bitmap getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(Bitmap thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public static final Creator<StoresSongData> CREATOR = new Creator<StoresSongData>() {
        @Override
        public StoresSongData createFromParcel(Parcel in) {
            StoresSongData ssd = new StoresSongData();
            ssd.title = in.readString();
            ssd.name = in.readString();
            ssd.thumbnail = Bitmap.CREATOR.createFromParcel(in);
            ssd.audio = in.readString();
            return ssd;
        }

        @Override
        public StoresSongData[] newArray(int size) {
            return new StoresSongData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(name);
        thumbnail.writeToParcel(dest, 0);
        dest.writeString(audio);
    }
}
