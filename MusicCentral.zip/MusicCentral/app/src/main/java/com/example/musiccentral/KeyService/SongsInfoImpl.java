package com.example.musiccentral.KeyService;

import android.app.Service;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.IBinder;

import com.example.KeyCommon.SongsInfo;
import com.example.KeyCommon.StoresSongData;
import com.example.musiccentral.R;

import java.util.Arrays;
import java.util.List;

public class SongsInfoImpl extends Service {

    List<String> songs = Arrays.asList("Thinking Out Loud", "Closer", "Lean On", "See You Again", "Paradise", "Cheap Thrills", "Wake Me Up", "Love Me Like You Do", "Uptown Funk", "Rolling In The Deep");
    List<String> artists = Arrays.asList("Ed Sheeran", "The Chainsmokers", "DJ Snake", "Wiz Khalifa", "Coldplay", "Sia", "Avicii", "Ellie Goulding", "Mark Ronson", "Adele");
    List<Integer> thumbnails = Arrays.asList(R.drawable.thinking, R.drawable.closer, R.drawable.leanon, R.drawable.seeyouagain, R.drawable.coldplay, R.drawable.cheapthrills, R.drawable.wake, R.drawable.love, R.drawable.uptown, R.drawable.rolling);
    List<String> linkSong = Arrays.asList("https://www.youtube.com/watch?v=lp-EO5I60KA&feature=youtu.be", "https://www.youtube.com/watch?v=PT2_F-1esPk", "https://www.youtube.com/watch?v=YqeW9_5kURI", "https://www.youtube.com/watch?v=RgKAFK5djSk", "https://www.youtube.com/watch?v=1G4isv_Fylg&feature=kp", "https://www.youtube.com/watch?v=nYh-n7EOtMA", "https://www.youtube.com/watch?v=IcrbM1l_BoI", "https://www.youtube.com/watch?v=AJtDXIazrMo", "https://www.youtube.com/watch?v=OPf0YbXqDm0", "https://www.youtube.com/watch?v=rYEDA3JcQqw");

    public StoresSongData[] songs_data(){
        StoresSongData[] songD = new StoresSongData[10];

        Integer counter = 0;
        while (counter < 10){
            songD[counter] = new StoresSongData();
        }

        for (int i = 0; i < songD.length; i++){
            songD[i].title = songs.get(i);
            songD[i].name = artists.get(i);
            songD[i].thumbnail = BitmapFactory.decodeResource(getResources(), thumbnails.get(i));
            songD[i].audio = linkSong.get(i);
        }

        return songD;
    }

    // Return the Stub defined above
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    // Implement the Stub for this Object
    SongsInfo.Stub mBinder = new SongsInfo.Stub() {

        @Override
        public String audioURL(int num){
            return songs_data()[num].audio;
        }

        @Override
        public StoresSongData[] retrieveAllSongs(){
            return songs_data();
        }

        @Override
        public StoresSongData retrieveSingleSong(int num){
            return songs_data()[num];
        }

        @Override
        public IBinder asBinder() {
            return super.asBinder();
        }
    };
}